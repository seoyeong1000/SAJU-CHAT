-- 900_seed_tables.sql
-- Seed 적재용 최소 테이블(원본 추적 + 섹션 저장)
-- DEV에서는 RLS OFF 권장

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS seed_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_file TEXT NOT NULL,
  source_doc_title TEXT,
  source_doc_index INT NOT NULL,
  raw_text TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 문서 멱등(권장)
CREATE UNIQUE INDEX IF NOT EXISTS uq_seed_documents_src
  ON seed_documents(source_file, source_doc_index);

CREATE TABLE IF NOT EXISTS saju_contents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL,
  logic_key TEXT NOT NULL,
  title TEXT,
  content_template TEXT NOT NULL,
  source_file TEXT NOT NULL,
  source_ref JSONB DEFAULT '{}'::jsonb,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 핵심: 멱등 유니크
CREATE UNIQUE INDEX IF NOT EXISTS uq_saju_contents_key
  ON saju_contents(category, logic_key);
