# Seed Script Pack (v1.1)

이 패키지는 **초기 데이터 시딩(Seed)**을 위해 필요한 **실제 코드**입니다.
- ETL 매핑 규격: `Seed_Data_ETL_Mapping_Spec_v1.0.md`를 구현으로 옮긴 버전
- 멱등성: 여러 번 실행해도 중복 적재되지 않도록 `UPSERT(onConflict)` 사용
- 대용량 대응: TXT는 문서/섹션 기준으로 chunking + 로그 출력

---

## 0) 이 ZIP 하나면 되나요?

- **Seed(초기 데이터 적재)만** 기준으로는: ✅ **이 ZIP(Seed Script Pack)만 있으면 됩니다.**
- 다만 프로젝트 전체 킥오프(개발 착수) 기준으로는:
  - PRD / 기능명세서 / NFR / DB 스키마 문서도 함께 전달되어야 개발자가 “의견 없이” 구현합니다.

---

## 1) 포함 파일

- `sql/900_seed_tables.sql`
  - `saju_contents` 적재를 돕는 보조 테이블(`seed_documents`) 정의
- `scripts/seed.ts`
  - `seed_data/` 폴더의 CSV/TXT를 파싱 → `saju_contents`, `seed_documents`에 적재
- `scripts/verify-ephe.js`
  - **배포 사고 방지기**: `public/ephe/*.se1` 누락 시 빌드(prebuild) 단계에서 실패 처리
- `.env.example`
  - 필요한 환경 변수 템플릿

---

## 2) 설치/실행 순서 (개발자용)

### Step A. 테이블 생성 (1회)

Supabase SQL Editor에서 아래 파일을 실행:
- `sql/900_seed_tables.sql`

> 이미 테이블이 있으면, 중복 생성 에러가 날 수 있으니 확인하고 진행하세요.

### Step B. seed_data 폴더 준비

프로젝트 루트에 아래 구조를 만든 뒤, 제공된 원본 파일들을 넣습니다.

```
seed_data/
  @1_8_통합자료.txt
  @삼송사주_통합_정리본.csv
  ...
```

### Step C. 환경 변수 설정

- `.env.local`에 최소 아래 2개를 설정:
  - `NEXT_PUBLIC_SUPABASE_URL`
  - `SUPABASE_SERVICE_ROLE_KEY`

### Step D. 실행

(권장) `tsx`를 사용합니다.

```bash
npm i -D tsx
npm run seed
```

---

## 3) package.json scripts (권장)

프로젝트의 `package.json`에 아래를 추가하세요.

```json
{
  "scripts": {
    "prebuild": "node scripts/verify-ephe.js",
    "seed": "tsx scripts/seed.ts"
  }
}
```

- `prebuild`: 배포/빌드 전에 ephe 파일 누락을 자동 탐지
- `seed`: seed_data → DB 적재

---

## 4) 옵션 (운영/테스트)

- Dry run:
  - `SEED_DRY_RUN=true` 로 실행하면 DB에 쓰지 않고 “몇 건 들어갈지”만 출력
- Seed 데이터 경로 변경:
  - `SEED_DATA_DIR=seed_data`

끝.
