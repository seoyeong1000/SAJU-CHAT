/**
 * scripts/verify-ephe.js
 * - 목적: 배포/빌드 전에 Swiss Ephemeris ephe 파일(*.se1) 누락을 잡아서 '배포 사고'를 원천 차단
 * - 사용: package.json에 prebuild로 연결 (README_SEED.md 참고)
 */
const fs = require("node:fs");
const path = require("node:path");

const EPHE_DIR = path.join(process.cwd(), "public", "ephe");

/**
 * swisseph-wasm에서 필요한 ephe 파일은 사용 옵션(천체/정밀도)에 따라 달라질 수 있습니다.
 * MVP에서는 '디렉토리 존재 + 최소 1개 se1 존재'를 강제하고,
 * 실제 운영에서 필요 파일 목록이 확정되면 REQUIRED_FILES에 추가해 강제하세요.
 */
const REQUIRED_FILES = process.env.SE_REQUIRED_EPHE_FILES
  ? process.env.SE_REQUIRED_EPHE_FILES.split(",").map((s) => s.trim()).filter(Boolean)
  : [];

function fail(msg) {
  console.error("❌ [verify-ephe] " + msg);
  process.exit(1);
}

console.log("🔍 [verify-ephe] Checking Swiss Ephemeris ephe files...");

if (!fs.existsSync(EPHE_DIR)) {
  fail(`Ephemeris directory not found: ${EPHE_DIR}\n👉 public/ephe/ 폴더에 *.se1 파일을 포함해 배포하세요.`);
}

const se1 = fs.readdirSync(EPHE_DIR).filter((f) => f.toLowerCase().endsWith(".se1"));
if (se1.length === 0) {
  fail(`No *.se1 files found in: ${EPHE_DIR}\n👉 public/ephe/ 폴더에 ephe 데이터(*.se1)를 넣어주세요.`);
}

if (REQUIRED_FILES.length > 0) {
  const missing = REQUIRED_FILES.filter((f) => !fs.existsSync(path.join(EPHE_DIR, f)));
  if (missing.length > 0) {
    fail(`Missing required ephe files: ${missing.join(", ")}\n👉 누락 파일을 public/ephe/에 추가하세요.`);
  }
}

console.log(`✅ [verify-ephe] OK. ephe_dir=${EPHE_DIR}, se1_count=${se1.length}`);
process.exit(0);
