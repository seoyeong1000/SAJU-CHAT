import path from 'node:path';
import fs from 'node:fs';
import dotenv from 'dotenv';
dotenv.config({ path: path.join(process.cwd(), '.env.local') });

import { getSupabaseAdmin } from './lib/supabase';
import { makeLogger } from './lib/logger';
import type { SeedStats } from './lib/seedTypes';
import { parseCsvToContents } from './lib/csvParser';
import { parseTxtToDocumentsAndContents, type TxtRules } from './lib/txtParser';

function boolEnv(name: string, def: boolean) {
  const v = (process.env[name] ?? '').toLowerCase().trim();
  if (!v) return def;
  return v === '1' || v === 'true' || v === 'yes';
}

async function upsertContents(supabase: any, rows: any[], dryRun: boolean, log: any) {
  if (dryRun) {
    log.info(`[DRY_RUN] would upsert saju_contents: ${rows.length} rows`);
    return;
  }
  const { error } = await supabase
    .from('saju_contents')
    .upsert(rows, { onConflict: 'category,logic_key' });
  if (error) throw error;
}

async function upsertDocuments(supabase: any, rows: any[], dryRun: boolean, log: any) {
  if (dryRun) {
    log.info(`[DRY_RUN] would upsert seed_documents: ${rows.length} docs`);
    return;
  }
  const { error } = await supabase
    .from('seed_documents')
    .upsert(rows, { onConflict: 'source_file,source_doc_index' });
  if (error) throw error;
}

function loadRules(): TxtRules {
  // rules are embedded as JSON so you can later replace with external file if you want.
  const rules = {"category_priority": ["investment", "health", "twelve_growth", "ten_gods", "five_elements", "ganji", "general", "rag_source"], "keywords": {"investment": ["투자", "금융", "종목", "매매", "차트", "리스크"], "health": ["황제내경", "장부", "경락", "건강", "식이", "처방", "치료"], "twelve_growth": ["십이운성", "장생", "목욕", "관대", "건록", "제왕", "쇠", "병", "사", "묘", "절", "태", "양"], "ten_gods": ["십성", "십신", "비견", "겁재", "식신", "상관", "편재", "정재", "편관", "정관", "편인", "정인"], "five_elements": ["오행", "목(", "화(", "토(", "금(", "수(", "목(木)", "화(火)", "토(土)", "금(金)", "수(水)"], "ganji": ["천간", "지지", "60갑자", "육십갑자", "일주", "간지"]}, "txt_doc_markers": ["^===== BEGIN .* =====$", "^BEGIN FILE: .*"], "txt_heading_patterns": ["^#{1,6}\\s+", "^(I|II|III|IV|V|VI|VII|VIII|IX|X)\\.\\s+", "^\\d+(\\.\\d+)*\\.\\s+"], "chunk_target_chars": [800, 1200], "logic_key_hash_len": 16};
  return {
    docMarkers: rules.txt_doc_markers.map((s: string) => new RegExp(s)),
    headingPatterns: rules.txt_heading_patterns.map((s: string) => new RegExp(s)),
    chunkTarget: { min: rules.chunk_target_chars[0], max: rules.chunk_target_chars[1] },
    categoryPriority: rules.category_priority,
    keywords: rules.keywords,
    logicKeyHashLen: rules.logic_key_hash_len,
  };
}

function listDataFiles(dir: string) {
  const abs = path.isAbsolute(dir) ? dir : path.join(process.cwd(), dir);
  if (!fs.existsSync(abs)) throw new Error(`SEED_DATA_DIR not found: ${abs}`);
  const entries = fs.readdirSync(abs).map((n) => path.join(abs, n));
  const csv = entries.filter((p) => p.toLowerCase().endsWith('.csv'));
  const txt = entries.filter((p) => p.toLowerCase().endsWith('.txt'));
  return { absDir: abs, csv, txt };
}

async function main() {
  const seedDir = process.env.SEED_DATA_DIR ?? 'seed_data';
  const dryRun = boolEnv('SEED_DRY_RUN', false);
  const logLevel = (process.env.SEED_LOG_LEVEL ?? 'info') as any;
  const log = makeLogger(logLevel);

  const { absDir, csv, txt } = listDataFiles(seedDir);
  log.info(`Seed data dir: ${absDir}`);
  log.info(`CSV files: ${csv.length}, TXT files: ${txt.length}`);

  const supabase = getSupabaseAdmin();
  const stats: SeedStats[] = [];

  // === CSV ===
  for (const f of csv) {
    const file = path.basename(f);
    const s: SeedStats = { file, type: 'CSV', docs_inserted: 0, contents_upserted: 0, skipped: 0, errors: 0 };
    try {
      let config: any = {};
      if (file.includes('삼송사주')) {
        config = { defaultCategory: 'general', fileCategoryColumn: 'category', idColumn: 'id', titleColumnCandidates: ['title'], contentColumn: 'content', linkColumn: 'link', dateColumn: 'date_iso' };
      } else if (file.includes('해밝')) {
        config = { fileCategoryColumn: 'category', idColumn: 'id', titleColumnCandidates: ['title'], contentColumn: 'content', linkColumn: 'url', dateColumn: 'date_iso' };
      } else if (file.includes('현묘')) {
        config = { defaultCategory: 'general', idColumn: 'id', titleColumnCandidates: ['detail_title','title'], contentColumn: 'content', linkColumn: 'link', dateColumn: 'date_iso' };
      } else if (file.includes('어바웃사주')) {
        config = { defaultCategory: 'general', idColumn: 'id', titleColumnCandidates: ['title'], contentColumn: 'content' };
      } else {
        config = { defaultCategory: 'general', idColumn: 'id', titleColumnCandidates: ['detail_title','title'], contentColumn: 'content' };
      }

      const { rows, skipped } = parseCsvToContents(f, config);
      s.skipped += skipped;
      s.contents_upserted += rows.length;

      // Upsert in chunks
      const chunkSize = 500;
      for (let i = 0; i < rows.length; i += chunkSize) {
        const chunk = rows.slice(i, i + chunkSize);
        await upsertContents(supabase, chunk, dryRun, log);
      }

      log.info(`[CSV] ${file} upserted=${rows.length} skipped=${skipped}`);
    } catch (e: any) {
      s.errors += 1;
      log.error(`[CSV] ${file} failed:`, e?.message ?? e);
    }
    stats.push(s);
  }

  // === TXT ===
  const rules = loadRules();
  for (const f of txt) {
    const file = path.basename(f);
    const s: SeedStats = { file, type: 'TXT', docs_inserted: 0, contents_upserted: 0, skipped: 0, errors: 0 };
    try {
      const parsed = await parseTxtToDocumentsAndContents(f, rules);
      s.docs_inserted += parsed.documents.length;
      s.contents_upserted += parsed.contents.length;
      s.skipped += parsed.skipped;

      // upsert documents
      const docChunk = 50;
      for (let i = 0; i < parsed.documents.length; i += docChunk) {
        await upsertDocuments(supabase, parsed.documents.slice(i, i + docChunk), dryRun, log);
      }

      // upsert contents
      const contentChunk = 200;
      for (let i = 0; i < parsed.contents.length; i += contentChunk) {
        await upsertContents(supabase, parsed.contents.slice(i, i + contentChunk), dryRun, log);
      }

      log.info(`[TXT] ${file} docs=${parsed.documents.length} contents=${parsed.contents.length} skipped=${parsed.skipped}`);
    } catch (e: any) {
      s.errors += 1;
      log.error(`[TXT] ${file} failed:`, e?.message ?? e);
    }
    stats.push(s);
  }

  // === Summary ===
  log.info('===== SEED SUMMARY =====');
  for (const s of stats) {
    log.info(`${s.type} ${s.file} | docs=${s.docs_inserted} contents=${s.contents_upserted} skipped=${s.skipped} errors=${s.errors}`);
  }

  const totalContents = stats.reduce((a, b) => a + b.contents_upserted, 0);
  const totalErrors = stats.reduce((a, b) => a + b.errors, 0);

  if (totalErrors > 0) {
    log.error(`Seed finished with errors=${totalErrors}`);
    process.exit(1);
  }
  log.info(`Seed finished OK. total_contents=${totalContents} (dryRun=${dryRun})`);
}

main().catch((e) => {
  console.error('Fatal:', e);
  process.exit(1);
});
