import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import type { SeedContentRow, SeedDocumentRow } from './seedTypes';
import { shortHash } from './hash';
import { normalizeNewlines, isTooShort, safeTitle } from './validators';

export type TxtRules = {
  docMarkers: RegExp[];
  headingPatterns: RegExp[];
  chunkTarget: { min: number; max: number };
  categoryPriority: string[];
  keywords: Record<string, string[]>;
  logicKeyHashLen: number;
};

type ParsedTxt = {
  documents: SeedDocumentRow[];
  contents: SeedContentRow[];
  skipped: number;
};

function detectCategory(text: string, rules: TxtRules): string {
  const t = text.toLowerCase();
  for (const cat of rules.categoryPriority) {
    const keys = rules.keywords[cat] ?? [];
    for (const k of keys) {
      if (!k) continue;
      if (t.includes(k.toLowerCase())) return cat;
    }
  }
  return 'general';
}

function isHeadingLine(line: string, patterns: RegExp[]) {
  return patterns.some((re) => re.test(line));
}

function cleanHeading(line: string) {
  return line
    .replace(/^#{1,6}\s+/, '')
    .replace(/^\s*(\d+(\.\d+)*)\.\s+/, '')
    .replace(/^\s*(I|II|III|IV|V|VI|VII|VIII|IX|X)\.\s+/i, '')
    .replace(/\*\*/g, '')
    .trim();
}

function splitIntoChunksByParagraph(text: string, minLen: number, maxLen: number): string[] {
  const paras = text.split(/\n\n+/);
  const chunks: string[] = [];
  let buf = '';

  function flush() {
    const v = buf.trim();
    if (v) chunks.push(v);
    buf = '';
  }

  for (const p of paras) {
    const piece = p.trim();
    if (!piece) continue;
    if ((buf + '\n\n' + piece).length <= maxLen) {
      buf = buf ? (buf + '\n\n' + piece) : piece;
      continue;
    }
    if (buf.length >= minLen) flush();
    // if single paragraph too big, hard cut
    if (piece.length > maxLen) {
      for (let i = 0; i < piece.length; i += maxLen) {
        chunks.push(piece.slice(i, i + maxLen));
      }
      continue;
    }
    buf = piece;
  }
  if (buf) flush();
  return chunks;
}

export async function parseTxtToDocumentsAndContents(absPath: string, rules: TxtRules): Promise<ParsedTxt> {
  const file = path.basename(absPath);

  const rl = readline.createInterface({
    input: fs.createReadStream(absPath, { encoding: 'utf-8' }),
    crlfDelay: Infinity,
  });

  const documents: SeedDocumentRow[] = [];
  let currentDocLines: string[] = [];
  let currentDocTitle: string | null = null;
  let docIndex = 0;

  const pushDoc = () => {
    const raw_text = normalizeNewlines(currentDocLines.join('\n')).trim();
    if (!isTooShort(raw_text, 30)) {
      documents.push({
        source_file: file,
        source_doc_title: currentDocTitle,
        source_doc_index: docIndex,
        raw_text,
        metadata: {},
      });
      docIndex += 1;
    }
    currentDocLines = [];
    currentDocTitle = null;
  };

  for await (const line of rl) {
    const s = String(line ?? '');
    const isMarker = rules.docMarkers.some((re) => re.test(s));
    if (isMarker) {
      if (currentDocLines.length) pushDoc();
      const cleaned = s.replace(/=+/g, '').replace(/^BEGIN FILE:\s*/i, '').replace(/^BEGIN\s*/i, '').trim();
      currentDocTitle = cleaned || null;
      continue;
    }
    currentDocLines.push(s);
  }
  if (currentDocLines.length) pushDoc();

  // Build contents by section-splitting each document
  const contents: SeedContentRow[] = [];
  let skipped = 0;

  for (const d of documents) {
    const lines = d.raw_text.split('\n');
    let headingPath: string[] = [];
    let sectionBuf: string[] = [];
    let sectionTitle: string | null = null;
    let sectionIndex = 0;

    const flushSection = () => {
      const body = normalizeNewlines(sectionBuf.join('\n')).trim();
      sectionBuf = [];
      if (isTooShort(body)) { skipped++; return; }

      const title = safeTitle(sectionTitle ?? (body.split('\n')[0] ?? '')) ?? `Section ${sectionIndex}`;
      const heading_path = headingPath.join(' > ');

      // If no meaningful headings, chunk by length
      if (!sectionTitle && body.length > rules.chunkTarget.max) {
        const chunks = splitIntoChunksByParagraph(body, rules.chunkTarget.min, rules.chunkTarget.max);
        chunks.forEach((ch, i) => {
          const cat = detectCategory(title + '\n' + ch, rules);
          const logic_key = shortHash(`${d.source_file}|${d.source_doc_title}|${heading_path}|${sectionIndex}|${i}`, rules.logicKeyHashLen);
          contents.push({
            category: cat,
            logic_key,
            title: safeTitle(`${title} (chunk ${i+1})`) ?? null,
            content_template: ch,
            source_file: d.source_file,
            source_ref: { source_doc_title: d.source_doc_title, source_doc_index: d.source_doc_index, heading_path, section_index: sectionIndex, chunk_index: i },
            metadata: { parser: 'txt_chunk' },
          });
        });
        sectionIndex++;
        return;
      }

      const cat = detectCategory((sectionTitle ?? '') + '\n' + body, rules);
      const logic_key = shortHash(`${d.source_file}|${d.source_doc_title}|${heading_path}|${sectionIndex}`, rules.logicKeyHashLen);

      contents.push({
        category: cat,
        logic_key,
        title,
        content_template: body,
        source_file: d.source_file,
        source_ref: { source_doc_title: d.source_doc_title, source_doc_index: d.source_doc_index, heading_path, section_index: sectionIndex },
        metadata: { parser: 'txt_section' },
      });
      sectionIndex++;
    };

    for (const line of lines) {
      if (isHeadingLine(line, rules.headingPatterns)) {
        if (sectionBuf.length) flushSection();
        const h = cleanHeading(line);
        sectionTitle = h || null;
        if (h) headingPath = [h];
        continue;
      }
      // simple: treat empty line as paragraph separator but keep
      sectionBuf.push(line);
    }
    if (sectionBuf.length) flushSection();
  }

  return { documents, contents, skipped };
}
