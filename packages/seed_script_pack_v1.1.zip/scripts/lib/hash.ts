import crypto from 'crypto';

export function sha1Hex(input: string) {
  return crypto.createHash('sha1').update(input).digest('hex');
}

export function shortHash(input: string, len = 16) {
  return sha1Hex(input).slice(0, len);
}
