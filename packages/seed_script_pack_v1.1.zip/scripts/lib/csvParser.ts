import fs from 'node:fs';
import path from 'node:path';
import { parse } from 'csv-parse/sync';
import type { SeedContentRow } from './seedTypes';
import { isTooShort, normalizeNewlines, safeTitle } from './validators';

type CsvConfig = {
  defaultCategory?: string;
  fileCategoryColumn?: string;
  idColumn?: string;
  titleColumnCandidates?: string[];
  contentColumn?: string;
  linkColumn?: string;
  dateColumn?: string;
  sourceFileColumn?: string;
};

export function parseCsvToContents(absPath: string, config: CsvConfig): { rows: SeedContentRow[]; skipped: number } {
  const raw = fs.readFileSync(absPath, 'utf-8');
  const records = parse(raw, {
    columns: true,
    skip_empty_lines: true,
    relax_quotes: true,
    relax_column_count: true,
    bom: true,
  }) as Record<string, any>[];

  const file = path.basename(absPath);
  const rows: SeedContentRow[] = [];
  let skipped = 0;

  for (const r of records) {
    const content = normalizeNewlines(String(r[config.contentColumn ?? 'content'] ?? ''));

    if (isTooShort(content)) {
      skipped++;
      continue;
    }

    const category = String(r[config.fileCategoryColumn ?? 'category'] ?? config.defaultCategory ?? 'general').trim() || 'general';
    const logic_key = String(r[config.idColumn ?? 'id'] ?? '').trim();
    if (!logic_key) {
      skipped++;
      continue;
    }

    const titleCandidates = config.titleColumnCandidates ?? ['detail_title', 'title'];
    let titleVal: string | null = null;
    for (const c of titleCandidates) {
      const v = safeTitle(String(r[c] ?? ''));
      if (v) { titleVal = v; break; }
    }

    const meta: Record<string, any> = {};
    if (config.linkColumn && r[config.linkColumn]) meta.link = String(r[config.linkColumn]);
    if (config.dateColumn && r[config.dateColumn]) meta.date_iso = String(r[config.dateColumn]);

    rows.push({
      category,
      logic_key,
      title: titleVal,
      content_template: content,
      source_file: file,
      metadata: meta,
      source_ref: {
        csv_row: rows.length,
      },
    });
  }

  return { rows, skipped };
}
