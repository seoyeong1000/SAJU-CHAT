export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export type SeedContentRow = {
  category: string;
  logic_key: string;
  title?: string | null;
  content_template: string;
  source_file: string;
  source_ref?: Record<string, any>;
  metadata?: Record<string, any>;
};

export type SeedDocumentRow = {
  source_file: string;
  source_doc_title?: string | null;
  source_doc_index: number;
  raw_text: string;
  metadata?: Record<string, any>;
};

export type SeedStats = {
  file: string;
  type: 'CSV' | 'TXT';
  docs_inserted: number;
  contents_upserted: number;
  skipped: number;
  errors: number;
};
