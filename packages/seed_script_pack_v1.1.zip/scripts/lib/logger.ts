import type { LogLevel } from './seedTypes';

const LEVEL_ORDER: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
};

export function makeLogger(level: LogLevel) {
  const threshold = LEVEL_ORDER[level] ?? LEVEL_ORDER.info;

  function should(lv: LogLevel) {
    return LEVEL_ORDER[lv] >= threshold;
  }

  return {
    debug: (...args: any[]) => should('debug') && console.log('[DEBUG]', ...args),
    info:  (...args: any[]) => should('info')  && console.log('[INFO ]', ...args),
    warn:  (...args: any[]) => should('warn')  && console.warn('[WARN ]', ...args),
    error: (...args: any[]) => should('error') && console.error('[ERROR]', ...args),
  };
}
