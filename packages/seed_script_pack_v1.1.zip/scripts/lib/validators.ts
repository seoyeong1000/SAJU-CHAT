export function isTooShort(text: string, minLen = 10) {
  return !text || text.trim().length < minLen;
}

export function normalizeNewlines(text: string) {
  return text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
}

export function safeTitle(title: string, maxLen = 80) {
  const t = (title ?? '').trim();
  if (!t) return null;
  return t.length > maxLen ? t.slice(0, maxLen) : t;
}
